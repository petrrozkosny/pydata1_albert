import pandas as pd

ted = pd.Timestamp.now()
df_ted = pd.DataFrame([ted],columns=['datum_a_cas'])

try:
    df_data = pd.read_csv('data.csv',sep=';')
    print('Nalezeno')
except FileNotFoundError:
    print('Nenalezeno')
    df_data = pd.DataFrame(columns=['datum_a_cas'])

if df_data.empty:
    print('prazdny')
    df_data_vse = df_ted
else:
    df_data_vse = pd.concat([df_data,df_ted],axis=0)
    print(df_data_vse)

df_data_vse.to_csv('data.csv',sep=';',index=False)